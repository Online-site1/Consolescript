import datetime

Run = True
code = []
string = 0

d = 0
r = 0

def Print():
	print(event[14:])

def Ver():
	print("1.0")	

def Info():
	print("Console script")
	print("Version 1.0")	

def Break():
	Run = False	

def date():
	print(datetime.datetime.today())	

def help():
	print("Console.print")	
	print("Console.ver")	
	print("Console.info")	
	print("break")	
	print("help")
	print("import t")	
	print("import r")	
	print("date")	

while Run:
	event = input()
	code.append(event)

	if "Console.print " in code[string]:Print()
	if "Console.ver" in code[string]:Ver()
	if "Console.info" in code[string]:Info()
	if "break" in code[string]:Blrak()
	if "help" in code[string]:help()
	if "import t" in code[string]:d = 1
	if "import r" in code[string]:r = 1

	if "date":
		if d == 1:
			date()	

	if "Консоль.печать " in code[string]:
		if r == 1:
			Print()		
	if "Консоль.версия" in code[string]:
		if r == 1:
			Ver()		
	if "Консоль.информация" in code[string]:
		if r == 1:
			Info()
	if "Сломать" in code[string]:
		if r == 1:
			Break()	
	if "помощь" in code[string]:
		if r == 1:
			help()		

	string += 1	